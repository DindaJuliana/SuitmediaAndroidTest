package com.example.suitmediaandroidtest.api

interface UserOnClickListener{

    fun onUserItemClicked(position: Int)

}